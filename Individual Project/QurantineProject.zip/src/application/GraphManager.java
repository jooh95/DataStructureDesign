package application;

import java.io.FileNotFoundException;
import java.util.LinkedList;

public class GraphManager {
	
	
	public LinkedList<Area>[] graph;
	private String disease;
	private String[] areaData;
	private String route;
	
	
	GraphManager(String disease) throws FileNotFoundException{
		int areaN = DataManager.areas.length;
		graph = new LinkedList[areaN];
		areaData = DataManager.areas;
		this.disease = disease;
		
		for(int i = 0; i < DataManager.areas.length; i++) {
			graph[i] = new LinkedList<Area>();
			graph[i].add(new Area(areaData[i], DataManager.getSIR(areaData[i], disease)));
		}
		route = new String("");
	}
	
	public String createGraph(String start) throws FileNotFoundException {
		
			if(start.equals("��걤����") && calculateSIR(disease, "��걤����") > 0) {
				
				String[] go = {"���ϵ�", "�λ걤����", "��󳲵�"};
				
				
				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
							}
						}
						
					}
				}

			}
			else if(start.equals("����������") && calculateSIR(disease, "����������") > 0) {
				String[] go = {"��û�ϵ�", "��û����", "����Ư����ġ��"};
				
				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
					
					
				}
			}
			else if(start.equals("���ֱ�����") && calculateSIR(disease, "���ֱ�����") > 0) {
				String[] go = {"���󳲵�"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}

			}
			else if(start.equals("���󳲵�")  && calculateSIR(disease, "���󳲵�") > 0) {
				String[] go = {"���ֱ�����", "����ϵ�","��󳲵�"};
				
				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("��󳲵�") && calculateSIR(disease, "��󳲵�") > 0) {
				String[] go = {"����ϵ�", "��걤����", "�λ걤����", "�뱸������", "���ϵ�", "���󳲵�"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("����ϵ�") && calculateSIR(disease, "����ϵ�") > 0) {
				
				String[] go = {"���󳲵�", "��󳲵�", "��û�ϵ�", "���ϵ�", "��û����"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("��⵵") && calculateSIR(disease, "��⵵") > 0) {
				String[] go = {"����Ư����", "��õ������", "������", "��û�ϵ�", "��û����"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("�λ걤����") && calculateSIR(disease, "�λ걤����") > 0) {
				String[] go = {"��걤����", "��󳲵�"};
				
				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("�뱸������") && calculateSIR(disease, "�뱸������") > 0) {
				String[] go = {"���ϵ�", "��󳲵�"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}

				}
			}
			else if(start.equals("��û�ϵ�") && calculateSIR(disease, "��û�ϵ�") > 0) {
				String[] go = {"��⵵", "������", "���ϵ�", "��û����", "����ϵ�", "����������", "����Ư����ġ��"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("��û����") && calculateSIR(disease, "��û����") > 0) {
				String[] go = {"��⵵", "��û�ϵ�", "����������", "����ϵ�", "����Ư����ġ��"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("����Ư����") && calculateSIR(disease, "����Ư����") > 0) {
				String[] go = {"��⵵", "��õ������"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("���ϵ�") && calculateSIR(disease, "���ϵ�") > 0) {
				String[] go = {"��û�ϵ�", "��󳲵�", "����������", "����ϵ�", "������", "��걤����"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("������") && calculateSIR(disease, "������") > 0) {
				String[] go = {"��⵵", "��û�ϵ�", "���ϵ�"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("��õ������") && calculateSIR(disease, "��õ������") > 0) {
				String[] go = {"��⵵", "����Ư����"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
			else if(start.equals("����Ư����ġ��") && calculateSIR(disease, "����Ư����ġ��") > 0) {
				String[] go = {"��û�ϵ�","��û����","����������"};

				for(int k = 0; k < go.length; k++) {
					
					boolean visited = false;
					String[] visit = route.split("/");
					for(int j = 0; j < visit.length; j++) {
						if(visit[j].equals(go[k])) {
							visited = true;
							break;
						}
					}
					
					if(!visited) {
						Area nextTo = new Area(go[k], DataManager.getSIR(go[k], disease));
						for(int i = 0; i < graph.length; i++) {
							if(graph[i].get(0).areaName.equals(start)) {
								graph[i].add(nextTo);
								route = route + go[k] + "/";
								createGraph(go[k]);
								
							}
						}
					}
				}
			}
		
		return route;
	}
	
	private float calculateSIR(String disease, String area) throws FileNotFoundException {
		
		float beta = DataManager.getBeta(disease);
		float gama = DataManager.getGama(disease);
		float N = DataManager.getN(area, disease);
		
		float S = 0f;
		float I = 0f;
		
		for(int i = 0; i < graph.length; i++) {
			if(graph[i].get(0).areaName.equals(area)) {
				
				S = graph[i].get(0).survived;
				
				I = graph[i].get(0).infected;
				
				break;
			}
		}
		
		return (beta * S * I) / N - gama * I; 
		
	}

	public void setStartRoute(String initialRoute) {
		// TODO Auto-generated method stub
		
		route = new String(initialRoute + "/");
		
	}

	public void resetRoute() {
		// TODO Auto-generated method stub
		route = new String("");
	}
	
}


class Area{
	int infected;
	int survived;
	int recovered;
	String areaName;
	
	Area(String areaName, int[] sir){
		this.areaName = new String(areaName);
		this.infected = sir[0];
		this.survived = sir[1];
		this.recovered = sir[2];
	}
}
