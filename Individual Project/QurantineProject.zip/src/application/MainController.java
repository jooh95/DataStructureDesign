package application;

import java.io.FileNotFoundException;
import java.util.Arrays;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

public class MainController{
	
	private boolean isChecked = false;
	private String start;
	private GraphManager graphManager;
	
	@FXML
	private Circle seoulNode,gwangjuNode, cnNode, cbNode, gnNode, gbNode, daeguNode, ulsanNode, 
	jbNode, jnNode, gwNode, ggNode, sejongNode, daejeonNode, incheonNode, busanNode;

	@FXML
	private ComboBox<String> disease_combobox, start_combobox;
	
	@FXML
	private Button spread_btn;
	
	@FXML
	private HBox spread_board;
	
	@FXML
	private Text spread_route;
	
	@FXML
    public void initialize() throws FileNotFoundException {
		setDefault();
		spread_btn.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				if(isChecked) {
						//System.out.println(graphManager.bfs(start, start + "/"));
						try {
							graphManager.setStartRoute(start);
							setVisitedNode(graphManager.createGraph(start));
							graphManager.resetRoute();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block

						}
				}
			}
		});
		
		start_combobox.getItems().addAll(DataManager.areas);
		
		start_combobox.valueProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				// TODO Auto-generated method stub
	        	
	        	setDefault();
				start = ov.getValue().toString();
				disease_combobox.getItems().clear();

				try {
					disease_combobox.getItems().addAll(DataManager.getDiseaseList(start));
					System.out.println(Arrays.toString(DataManager.getDiseaseList(start)));
					
					disease_combobox.valueProperty().addListener(new ChangeListener<String>() {
				        @Override public void changed(ObservableValue ov, String t, String t1) {
				        	
				        	setDefault();
				        	isChecked = true;

				        	try {
					        	String selectedDisease = ov.getValue().toString();
				        		graphManager = new GraphManager(selectedDisease);
				        		setStartNode(start);
									
							} catch (Exception e) {
								// TODO Auto-generated catch block
							}
				              
				          }    
				      });
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
				}
			}
		
		});
	}
	
	private void setStartNode(String start) {
		if(start.equals("��õ������")){
			incheonNode.setFill(Color.BROWN);
		}
		else if(start.equals("����Ư����")) {
			seoulNode.setFill(Color.BROWN);
		}
		else if(start.equals("�λ걤����")) {
			busanNode.setFill(Color.BROWN);
		}
		else if(start.equals("���ֱ�����")) {
			gwangjuNode.setFill(Color.BROWN);
		}
		else if(start.equals("�뱸������")) {
			daeguNode.setFill(Color.BROWN);
		}
		else if(start.equals("����������")) {
			daejeonNode.setFill(Color.BROWN);
		}
		else if(start.equals("��걤����")) {
			ulsanNode.setFill(Color.BROWN);
		}
		else if(start.equals("����Ư����ġ��")) {
			sejongNode.setFill(Color.BROWN);
		}
		else if(start.equals("��󳲵�")) {
			gnNode.setFill(Color.BROWN);
		}
		else if(start.equals("���ϵ�")) {
			gbNode.setFill(Color.BROWN);
		}
		else if(start.equals("���󳲵�")) {
			jnNode.setFill(Color.BROWN);
		}
		else if(start.equals("����ϵ�")) {
			jbNode.setFill(Color.BROWN);
		}
		else if(start.equals("������")) {
			gwNode.setFill(Color.BROWN);
		}
		else if(start.equals("��û����")) {
			cnNode.setFill(Color.BROWN);
		}
		else if(start.equals("��û�ϵ�")) {
			cbNode.setFill(Color.BROWN);
		}
		else if(start.equals("��⵵")) {
			ggNode.setFill(Color.BROWN);
		}
	}
	
	private void setVisitedNode(String visited) {
		spread_board.setVisible(true);
		spread_route.setText(visited.replaceAll("/", "\n"));
		
		String[] visit = visited.split("/");
		
		for(int i = 1; i < visit.length; i++) {
			if(visit[i].equals("��õ������")){
				incheonNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("����Ư����")) {
				seoulNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("�λ걤����")) {
				busanNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("���ֱ�����")) {
				gwangjuNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("�뱸������")) {
				daeguNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("����������")) {
				daejeonNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("��걤����")) {
				ulsanNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("����Ư����ġ��")) {
				sejongNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("��󳲵�")) {
				gnNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("���ϵ�")) {
				gbNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("���󳲵�")) {
				jnNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("����ϵ�")) {
				jbNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("������")) {
				gwNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("��û����")) {
				cnNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("��û�ϵ�")) {
				cbNode.setFill(Color.INDIANRED);
			}
			else if(visit[i].equals("��⵵")) {
				ggNode.setFill(Color.INDIANRED);
			}
		}
	}
	
	private void setDefault() {
		isChecked = false;
		spread_board.setVisible(false);
		incheonNode.setFill(Color.DODGERBLUE);
		seoulNode.setFill(Color.DODGERBLUE);
		busanNode.setFill(Color.DODGERBLUE);
		ggNode.setFill(Color.DODGERBLUE);
		cbNode.setFill(Color.DODGERBLUE);
		cnNode.setFill(Color.DODGERBLUE);
		gnNode.setFill(Color.DODGERBLUE);
		gbNode.setFill(Color.DODGERBLUE);
		jbNode.setFill(Color.DODGERBLUE);
		jnNode.setFill(Color.DODGERBLUE);
		gwNode.setFill(Color.DODGERBLUE);
		daejeonNode.setFill(Color.DODGERBLUE);
		ulsanNode.setFill(Color.DODGERBLUE);
		gwangjuNode.setFill(Color.DODGERBLUE);
		daeguNode.setFill(Color.DODGERBLUE);
		sejongNode.setFill(Color.DODGERBLUE);
	}
	
	
	
}