package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;

public class DataManager {
	
	static String fileName = "����.csv";
	static String[] areas = {"�λ걤����", "��걤����", "����������", "����Ư����ġ��", "�뱸������", "����Ư����",
			"���ֱ�����", "��õ������", "��⵵", "��󳲵�", "���ϵ�", "��û����", "��û�ϵ�", "������"
			,"����ϵ�", "���󳲵�"};
	
	//static String[] areas = {"�λ걤����", "��õ������"};
	
	static public String[] getDiseaseList(String start) throws FileNotFoundException {
		
		File file = new File(start + ".csv");
		
		Scanner sc = new Scanner(file);
		
		sc.nextLine();

		
		LinkedList<String> list = new LinkedList<String>();
		
		while(sc.hasNext()) {
			
			String[] inputs = sc.nextLine().split(",");
			
			list.add(inputs[0]);

		}
		
		String[] str = new String[list.size()];
		
		for(int i = 0; i < list.size(); i++) {
			str[i] = list.get(i);
		}
		

		return str;
		
	}
	
	
	static public String[] searchStartArea(String disease) throws FileNotFoundException {
		int areaN = areas.length;
		
		File[] files = new File[areaN];
		
		LinkedList<String> areaName = new LinkedList<String>();
		
		for(int i = 0; i < areaN; i++) {
			files[i] = new File(areas[i] + ".csv");
			
			
			Scanner sc = new Scanner(files[i]);
			sc.nextLine();
			
			while(sc.hasNext()) {
				String[] inputs = sc.nextLine().split(",");
				
				String disease_name = new String(inputs[0]);
				
				if(disease_name.equals(disease)) {
					areaName.add(areas[i]);
				}
			}
			
			
		}
		
		String[] str = new String[areaName.size()];
		
		for(int i = 0; i < str.length; i++) {
			str[i] = new String(areaName.get(i));
		}
		
		
		return str;
	}
	
	
	static public float getBeta(String disease) throws FileNotFoundException {
		File diseaseFile = new File(fileName);
		
		Scanner sc = new Scanner(diseaseFile);
		
		sc.nextLine();
		
		float result = 0f;
		
		while(sc.hasNext()) {
			
			String[] inputs = sc.nextLine().split(",");
			
			if(inputs[0].equals(disease)) {
				result = Float.parseFloat(inputs[2]);
			}
		}

		return result; 
	}
	
	static public float getGama(String disease) throws FileNotFoundException {
		
		File diseaseFile = new File(fileName);
		
		Scanner sc = new Scanner(diseaseFile);
		
		sc.nextLine();
		
		float result = 0f;
		
		while(sc.hasNext()) {
			
			String[] inputs = sc.nextLine().split(",");
			
			if(inputs[0].equals(disease)) {
				result = Float.parseFloat(inputs[1]);
			}
		}

		return result; 
	}

	
	static public int[] getSIR(String areaName, String disease) throws FileNotFoundException {
		
		int areaN = areas.length;
		
		
		File areafile = new File(areaName + ".csv");
			
		Scanner sc = new Scanner(areafile);
		sc.nextLine();
			
		int[] sir = new int[3];
			
		while(sc.hasNext()) {
			String[] inputs = sc.nextLine().split(",");
			
			if(inputs[0].equals(disease)) {
				sir[0] = Integer.parseInt(inputs[1]);
				sir[1] = Integer.parseInt(inputs[2]);
				sir[2] = Integer.parseInt(inputs[3]);
			}	
		}
		
		
		return sir;
	}


	public static float getN(String areaName, String disease) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		File file = new File(areaName + ".csv");
			
		Scanner sc = new Scanner(file);
		sc.nextLine();
			
		float result = 0.f;
			
		while(sc.hasNext()) {
			String[] inputs = sc.nextLine().split(",");
			
			if(inputs[0].equals(disease)) {
				result = Float.parseFloat(inputs[1]) + Float.parseFloat(inputs[2]) + Float.parseFloat(inputs[3]);
			}	
		}
		
		
		return result;
	}
}
